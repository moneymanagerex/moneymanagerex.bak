//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CrashExplorer.rc
//
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDS_INVALIDCRASHADDRESS         102
#define IDD_MAIN                        102
#define IDS_PROJECTTITLE                103
#define IDS_NOFUNCTIONINFO              104
#define IDS_INVALIDBASEADDRESS          105
#define IDS_INVALIDMAPPDBFILE           106
#define IDS_NOSOURCEFILEINFO            107
#define IDS_NOLINEINFO                  108
#define IDS_ERROR_UNSUPPORTEDPLATFORM   109
#define IDS_MANUALMODE                  115
#define IDS_EXPRESSMODE                 116
#define IDS_SELECTMAPPDBFOLDER          117
#define IDS_INVALIDLOGFILE              118
#define IDS_INVALIDMAPPDBFOLDER         119
#define IDS_ERROR_UNDEFINEDERROR        120
#define IDS_ERROR_XMLLOADERROR          121
#define IDS_ERROR_UNSUPPORTEDREPORTVERSION 122
#define IDS_COLUMN_FUNCTION             123
#define IDS_COLUMN_ADDRESS              124
#define IDS_COLUMN_FILE                 125
#define IDS_COLUMN_LINE                 126
#define IDS_COLUMN_MODULE               127
#define IDR_MAINFRAME                   128
#define IDS_INVALIDMODULESIZE           128
#define IDD_WAIT                        129
#define IDD_MANUAL_MODE                 132
#define IDD_EXPRESS_MODE                133
#define IDR_RADIX_CONTEXT               133
#define IDC_MAPPDBFILE                  1000
#define IDC_MAPPDBFILE_BROWSE           1002
#define IDC_BASEADDRESS                 1003
#define IDC_CRASHADDRESS                1004
#define IDC_SOURCEFILE                  1005
#define IDC_FUNCTIONNAME                1006
#define IDC_LINENUMBER                  1007
#define IDC_URL                         1008
#define IDC_MODES                       1020
#define IDC_MAPPDBFILE_LABEL            1021
#define IDC_BASEADDRESS_LABEL           1022
#define IDC_CRASHADDRESS_LABEL          1023
#define IDC_SOURCEFILE_LABEL            1024
#define IDC_FUNCTIONNAME_LABEL          1025
#define IDC_LINENUMBER_LABEL            1026
#define IDC_LOGFILE_LABEL               1027
#define IDC_LOGFILE                     1028
#define IDC_LOGFILE_BROWSE              1029
#define IDC_MAPPDBFOLDER_LABEL          1030
#define IDC_MAPPDBFOLDER                1031
#define IDC_MAPPDBFOLDER_BROWSE         1032
#define IDC_STACK_TRACE_GROUP           1034
#define IDC_STACK_TRACE                 1035
#define IDC_COPY                        1036
#define IDC_ERROR_REASON_GROUP          1037
#define IDC_ERROR_REASON                1038
#define IDC_SAVE                        1039
#define IDC_MODULESIZE                  1040
#define IDC_MODULESIZE_LABEL            1041
#define IDC_MODULESIZE_RADIX            1042
#define IDC_BASEADDRESS_RADIX           1043
#define IDC_VERSION_STRING              1043
#define IDC_CRASHADDRESS_RADIX          1046
#define ID_RADIX_HEX                    32773
#define ID_RADIX_DEC                    32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1044
#define _APS_NEXT_SYMED_VALUE           103
#endif
#endif
