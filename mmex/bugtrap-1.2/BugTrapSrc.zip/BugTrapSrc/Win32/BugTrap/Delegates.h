/*
 * This is a part of the BugTrap package.
 * Copyright (c) 2005-2007 IntelleSoft.
 * All rights reserved.
 *
 * Description: Overload delegate classes for different number of arguments.
 * Author: Maksim Pyatkovskiy.
 *
 * This source code is only intended as a supplement to the
 * BugTrap package reference and related electronic documentation
 * provided with the product. See these sources for detailed
 * information regarding the BugTrap package.
 */

#pragma once

#define DELEGATES_PARTIAL_SPECIALIZATION
//#define DELGATES_VECTOR
//#define DELEGATES_RTTI

#ifdef DELGATES_VECTOR
 #include "SmartPtr.h"
#else
 #include "Array.h"
#endif /* ! DELGATES_VECTOR */

#include "DelegatesPreProcessing.h"
#include "DelegatesBase.h"

#define DELEGATE_ARITY 0
#include "DelegateTemplates.h"
#undef DELEGATE_ARITY

#define DELEGATE_ARITY 1
#include "DelegateTemplates.h"
#undef DELEGATE_ARITY

#define DELEGATE_ARITY 2
#include "DelegateTemplates.h"
#undef DELEGATE_ARITY

#define DELEGATE_ARITY 3
#include "DelegateTemplates.h"
#undef DELEGATE_ARITY

#define DELEGATE_ARITY 4
#include "DelegateTemplates.h"
#undef DELEGATE_ARITY

#define DELEGATE_ARITY 5
#include "DelegateTemplates.h"
#undef DELEGATE_ARITY

#define DELEGATE_ARITY 6
#include "DelegateTemplates.h"
#undef DELEGATE_ARITY

#define DELEGATE_ARITY 7
#include "DelegateTemplates.h"
#undef DELEGATE_ARITY

#define DELEGATE_ARITY 8
#include "DelegateTemplates.h"
#undef DELEGATE_ARITY

#define DELEGATE_ARITY 9
#include "DelegateTemplates.h"
#undef DELEGATE_ARITY

#define DELEGATE_ARITY 10
#include "DelegateTemplates.h"
#undef DELEGATE_ARITY

/*
 ******************************************************
 * EXAMPLE ********************************************
 ******************************************************

	#include "Delegates.h"

	void StaticFunction(int) { }

	class Class
	{
	public:
		void Method(int) { }
	};

	///////////////////////////////////////////////////
	// Static delegate
	typedef CStaticDelegate<void (*)(int)> TDelegate1;
	TDelegate1 del1(StaticFunction);
	del1(123);

	///////////////////////////////////////////////////
	// Class instance delegate
	Class obj;
	typedef CDelegate<void (Class::*)(int)> TDelegate2;
	TDelegate2 del2(obj, &Class::Method);
	del2(123);

	///////////////////////////////////////////////////
	// Multi-delegate
	typedef CMultiDelegate<void (*)(int)> TDelegate3;
	TDelegate3 del3;
	del3 += del1;
	del3 += del2;
	del3(123);

 ******************************************************
 */
