/*
 * This is a part of the BugTrap package.
 * Copyright (c) 2005-2007 IntelleSoft.
 * All rights reserved.
 *
 * Description: Base delegate classes.
 * Author: Maksim Pyatkovskiy.
 *
 * This source code is only intended as a supplement to the
 * BugTrap package reference and related electronic documentation
 * provided with the product. See these sources for detailed
 * information regarding the BugTrap package.
 */

#pragma once

template <class PDelegate, class PClass, typename PFunction, typename PConstFunction>
class CDelegateData
{
public:
	typedef PClass TClass;
	typedef PFunction TFunction;
	typedef PConstFunction TConstFunction;

	CDelegateData(PClass& obj, PFunction func) : m_obj(&obj), m_func(func) { }
	CDelegateData(PClass* obj, PFunction func) : m_obj(obj), m_func(func) { }
	CDelegateData(PClass& obj, PConstFunction cfunc) : m_obj(&obj), m_func((PFunction)cfunc) { }
	CDelegateData(PClass* obj, PConstFunction cfunc) : m_obj(obj), m_func((PFunction)cfunc) { }

	friend bool operator==(const PDelegate& rDelegate1, const PDelegate& rDelegate2)
	{
		return (rDelegate1.m_obj == rDelegate2.m_obj && rDelegate1.m_func == rDelegate2.m_func);
	}

	friend bool operator!=(const PDelegate& rDelegate1, const PDelegate& rDelegate2)
	{
		return (rDelegate1.m_obj != rDelegate2.m_obj || rDelegate1.m_func != rDelegate2.m_func);
	}

	friend bool operator<(const PDelegate& rDelegate1, const PDelegate& rDelegate2)
	{
		return (rDelegate1.m_obj < rDelegate2.m_obj || (rDelegate1.m_obj == rDelegate2.m_obj && rDelegate1.m_func < rDelegate2.m_func));
	}

	friend bool operator<=(const PDelegate& rDelegate1, const PDelegate& rDelegate2)
	{
		return (rDelegate1.m_obj < rDelegate2.m_obj || (rDelegate1.m_obj == rDelegate2.m_obj && rDelegate1.m_func <= rDelegate2.m_func));
	}

	friend bool operator>(const PDelegate& rDelegate1, const PDelegate& rDelegate2)
	{
		return (rDelegate1.m_obj > rDelegate2.m_obj || (rDelegate1.m_obj == rDelegate2.m_obj && rDelegate1.m_func > rDelegate2.m_func));
	}

	friend bool operator>=(const PDelegate& rDelegate1, const PDelegate& rDelegate2)
	{
		return (rDelegate1.m_obj > rDelegate2.m_obj || (rDelegate1.m_obj == rDelegate2.m_obj && rDelegate1.m_func >= rDelegate2.m_func));
	}

	PFunction GetFunction() { return m_func; }
	PConstFunction GetFunction() const { return ((PConstFunction)m_func); }

	PClass* GetObject() { return m_obj; }
	const PClass* GetObject() const { return m_obj; }

protected:
	PClass* m_obj;
	PFunction m_func;
};

template <class PDelegate, typename PFunction>
class CStaticDelegateData
{
public:
	typedef PFunction TFunction;

	explicit CStaticDelegateData(PFunction func) : m_func(func) { }

	friend bool operator==(const PDelegate& rDelegate1, const PDelegate& rDelegate2)
	{
		return (rDelegate1.m_func == rDelegate2.m_func);
	}

	friend bool operator!=(const PDelegate& rDelegate1, const PDelegate& rDelegate2)
	{
		return (rDelegate1.m_func != rDelegate2.m_func);
	}

	friend bool operator<(const PDelegate& rDelegate1, const PDelegate& rDelegate2)
	{
		return (rDelegate1.m_func < rDelegate2.m_func);
	}

	friend bool operator<=(const PDelegate& rDelegate1, const PDelegate& rDelegate2)
	{
		return (rDelegate1.m_func <= rDelegate2.m_func);
	}

	friend bool operator>(const PDelegate& rDelegate1, const PDelegate& rDelegate2)
	{
		return (rDelegate1.m_func > rDelegate2.m_func);
	}

	friend bool operator>=(const PDelegate& rDelegate1, const PDelegate& rDelegate2)
	{
		return (rDelegate1.m_func >= rDelegate2.m_func);
	}

	PFunction GetFunction() { return m_func; }

protected:
	PFunction m_func;
};

template <class PBaseDelegate>
class CBaseMultiDelegate
{
public:
	virtual ~CBaseMultiDelegate() { }

#ifdef DELGATES_VECTOR
	bool IsEmpty() const { return m_delegates.empty(); }
	void Clear() { m_delegates.clear(); }
#else
	bool IsEmpty() const { return m_delegates.IsEmpty(); }
	void Clear() { m_delegates.DeleteAll(); }
#endif /* ! DELGATES_VECTOR */

	template <class PDelegate>
	CBaseMultiDelegate& operator+=(const PDelegate& rDelegate);

#ifdef DELEGATES_RTTI
	template <class PDelegate>
	CBaseMultiDelegate& operator-=(const PDelegate& rDelegate);
#endif /* DELEGATES_RTTI */

protected:
#ifdef DELGATES_VECTOR
	typedef CSmartPtr<PBaseDelegate> TDelegateElement;
	typedef std::vector<TDelegateElement> TDelegatesArray;
#else
	typedef PBaseDelegate* TDelegateElement;
	typedef CArray<TDelegateElement, CDynamicTraits<TDelegateElement> > TDelegatesArray;
#endif /* ! DELGATES_VECTOR */

	TDelegatesArray m_delegates;

private:
#if defined DELEGATES_RTTI && defined DELGATES_VECTOR
	class CDelegateFinder
	{
	public:
		explicit CDelegateFinder(const PBaseDelegate* pDelegate) : m_pDelegate(pDelegate) { }
		bool operator()(const PBaseDelegate* pDelegate) { return (m_pDelegate->Equals(*pDelegate)); }

	private:
		const PBaseDelegate* m_pDelegate;
	};
#endif /* DELEGATES_RTTI && DELGATES_VECTOR */
};

template <class PBaseDelegate>
template <class PDelegate>
CBaseMultiDelegate<PBaseDelegate>& CBaseMultiDelegate<PBaseDelegate>::operator+=(const PDelegate& rDelegate)
{
#ifdef DELEGATES_RTTI
 #ifdef DELGATES_VECTOR
	if (std::find_if(m_delegates.begin(), m_delegates.end(), CDelegateFinder(&rDelegate)) != m_delegates.end())
		return *this;
 #else
	int i, nCount = m_delegates.GetCount();
	for (i = 0; i < nCount; ++i)
	{
		if (m_delegates[i]->Equals(rDelegate))
			return *this;
	}
 #endif /* ! DELGATES_VECTOR */
#endif /* DELEGATES_RTTI */
#ifdef DELGATES_VECTOR
	m_delegates.push_back(TDelegateElement(new PDelegate(rDelegate)));
#else
	m_delegates.AddItem(TDelegateElement(new PDelegate(rDelegate)));
#endif /* ! DELGATES_VECTOR */
	return *this;
}

#ifdef DELEGATES_RTTI
template <class PBaseDelegate>
template <class PDelegate>
CBaseMultiDelegate<PBaseDelegate>& CBaseMultiDelegate<PBaseDelegate>::operator-=(const PDelegate& rDelegate)
{
#ifdef DELGATES_VECTOR
	typename TDelegatesArray::iterator it = std::find_if(m_delegates.begin(), m_delegates.end(), CDelegateFinder(&rDelegate));
	if (it != m_delegates.end())
		m_delegates.erase(it);
#else
	int i, nCount = m_delegates.GetCount();
	for (i = 0; i < nCount; ++i)
	{
		if (m_delegates[i]->Equals(rDelegate))
		{
			m_delegates.DeleteItem(i);
			break;
		}
	}
#endif /* ! DELGATES_VECTOR */
	return *this;
}
#endif /* DELEGATES_RTTI */

#ifdef DELEGATES_PARTIAL_SPECIALIZATION

template <typename PSignature>
class CDelegate;

template <typename PSignature>
class CStaticDelegate;

template <typename PSignature>
class CMultiDelegate;

#endif /* DELEGATES_PARTIAL_SPECIALIZATION */
