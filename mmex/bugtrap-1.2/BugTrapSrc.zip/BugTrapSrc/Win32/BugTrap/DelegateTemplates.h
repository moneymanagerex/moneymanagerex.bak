/*
 * This is a part of the BugTrap package.
 * Copyright (c) 2005-2007 IntelleSoft.
 * All rights reserved.
 *
 * Description: Delegates implementation.
 * Author: Maksim Pyatkovskiy.
 *
 * This source code is only intended as a supplement to the
 * BugTrap package reference and related electronic documentation
 * provided with the product. See these sources for detailed
 * information regarding the BugTrap package.
 */

#if DELEGATE_ARITY > 0
 #define LEADING_COMMA ,
#else
 #define LEADING_COMMA
#endif

#define DELEGATE_PARAMS_TYPENAMES    REPEAT_ITEM_N(typename PParam, DELEGATE_ARITY)
#define DELEGATE_PARAMS_TYPES        REPEAT_ITEM_N(PParam, DELEGATE_ARITY)
#define DELEGATE_PARAMS_VARS         REPEAT_ITEM_N(param, DELEGATE_ARITY)
#define DELEGATE_PARAMS_DEFS         REPEAT_TWOITEMS_N(PParam, param, DELEGATE_ARITY)

#define DBaseDelegateN               ITEM_N(CBaseDelegate, DELEGATE_ARITY)
#define DBaseDelegate                DBaseDelegateN<PReturn LEADING_COMMA DELEGATE_PARAMS_TYPES>
#define DDelegateN                   ITEM_N(CDelegate, DELEGATE_ARITY)
#define DDelegate                    DDelegateN<PClass, PReturn LEADING_COMMA DELEGATE_PARAMS_TYPES>
#define DStaticDelegateN             ITEM_N(CStaticDelegate, DELEGATE_ARITY)
#define DStaticDelegate              DStaticDelegateN<PReturn LEADING_COMMA DELEGATE_PARAMS_TYPES>
#define DFunction                    PReturn (PClass::*)(DELEGATE_PARAMS_TYPES)
#define DStaticFunction              PReturn (*)(DELEGATE_PARAMS_TYPES)
#define DDelegateData                CDelegateData<DDelegate, PClass, DFunction, DFunction const>
#define DStaticDelegateData          CStaticDelegateData<DStaticDelegate, DStaticFunction>
#define DBaseMultiDelegate           CBaseMultiDelegate<DBaseDelegate >
#define DMultiDelegateN              ITEM_N(CMultiDelegate, DELEGATE_ARITY)
#define DMultiDelegate               DMultiDelegateN<PReturn LEADING_COMMA DELEGATE_PARAMS_TYPES>

template <typename PReturn LEADING_COMMA DELEGATE_PARAMS_TYPENAMES>
class DBaseDelegateN
{
public:
	virtual ~DBaseDelegateN() { }

	virtual PReturn operator()(DELEGATE_PARAMS_DEFS) = 0;
	virtual PReturn operator()(DELEGATE_PARAMS_DEFS) const = 0;

#ifdef DELEGATES_RTTI
	virtual bool Equals(const DBaseDelegateN& rDelegate) const = 0;
#endif /* DELEGATES_RTTI */
};

template <class PClass, typename PReturn LEADING_COMMA DELEGATE_PARAMS_TYPENAMES>
class DDelegateN : public DBaseDelegate, public DDelegateData
{
public:
	DDelegateN(PClass& obj, typename DDelegateData::TFunction func) : DDelegateData(obj, func) { }
	DDelegateN(PClass* obj, typename DDelegateData::TFunction func) : DDelegateData(obj, func) { }
	DDelegateN(PClass& obj, typename DDelegateData::TConstFunction cfunc) : DDelegateData(obj, cfunc) { }
	DDelegateN(PClass* obj, typename DDelegateData::TConstFunction cfunc) : DDelegateData(obj, cfunc) { }

	virtual PReturn operator()(DELEGATE_PARAMS_DEFS) { return (m_obj->*m_func)(DELEGATE_PARAMS_VARS); }
	virtual PReturn operator()(DELEGATE_PARAMS_DEFS) const { return (m_obj->*m_func)(DELEGATE_PARAMS_VARS); }

#ifdef DELEGATES_RTTI
	virtual bool Equals(const DBaseDelegate& rDelegate) const
	{
		const DDelegate* pDelegate = dynamic_cast<const DDelegate*>(&rDelegate);
		return (pDelegate != 0 ? operator==(*this, *pDelegate) : false);
	}
#endif /* DELEGATES_RTTI */
};

template <typename PReturn LEADING_COMMA DELEGATE_PARAMS_TYPENAMES>
class DStaticDelegateN : public DBaseDelegate, public DStaticDelegateData
{
public:
	explicit DStaticDelegateN(typename DStaticDelegateData::TFunction func) : DStaticDelegateData(func) { }
	virtual PReturn operator()(DELEGATE_PARAMS_DEFS) { return (*m_func)(DELEGATE_PARAMS_VARS); }
	virtual PReturn operator()(DELEGATE_PARAMS_DEFS) const { return (*m_func)(DELEGATE_PARAMS_VARS); }

#ifdef DELEGATES_RTTI
	virtual bool Equals(const DBaseDelegate& rDelegate) const
	{
		const DStaticDelegate* pDelegate = dynamic_cast<const DStaticDelegate*>(&rDelegate);
		return (pDelegate != 0 ? operator==(*this, *pDelegate) : false);
	}
#endif /* DELEGATES_RTTI */
};

template <typename PReturn LEADING_COMMA DELEGATE_PARAMS_TYPENAMES>
class DMultiDelegateN : public DBaseMultiDelegate
{
public:
	PReturn operator()(DELEGATE_PARAMS_DEFS);
};

template <typename PReturn LEADING_COMMA DELEGATE_PARAMS_TYPENAMES>
PReturn DMultiDelegate::operator()(DELEGATE_PARAMS_DEFS)
{
#ifdef DELGATES_VECTOR
	typename DBaseMultiDelegate::TDelegatesArray::iterator it = m_delegates.begin(), end = m_delegates.end();
	if (it == end)
		return PReturn();
	for (;;)
	{
		DBaseDelegate* pDelegate = *it;
		if (++it == end)
			return pDelegate->operator()(DELEGATE_PARAMS_VARS);
		else
			pDelegate->operator()(DELEGATE_PARAMS_VARS);
	}
#else
	if (m_delegates.IsEmpty())
		return PReturn();
	int i = 0, nCount = m_delegates.GetCount();
	for (;;)
	{
		DBaseDelegate* pDelegate = m_delegates[i];
		if (++i == nCount)
			return pDelegate->operator()(DELEGATE_PARAMS_VARS);
		else
			pDelegate->operator()(DELEGATE_PARAMS_VARS);
	}
#endif
}

#ifdef DELEGATES_PARTIAL_SPECIALIZATION

template <class PClass, typename PReturn LEADING_COMMA DELEGATE_PARAMS_TYPENAMES>
class CDelegate<DFunction> : public DDelegate
{
public:
	CDelegate(PClass& obj, typename DDelegate::TFunction func) : DDelegate(obj, func) { }
	CDelegate(PClass* obj, typename DDelegate::TFunction func) : DDelegate(obj, func) { }
	CDelegate(PClass& obj, typename DDelegate::TConstFunction cfunc) : DDelegate(obj, cfunc) { }
	CDelegate(PClass* obj, typename DDelegate::TConstFunction cfunc) : DDelegate(obj, cfunc) { }
};

template <typename PReturn LEADING_COMMA DELEGATE_PARAMS_TYPENAMES>
class CDelegate<DStaticFunction> : public DStaticDelegate
{
public:
	explicit CDelegate(typename DStaticDelegate::TFunction func) : DStaticDelegate(func) { }
};

template <typename PReturn LEADING_COMMA DELEGATE_PARAMS_TYPENAMES>
class CStaticDelegate<DStaticFunction> : public DStaticDelegate
{
public:
	explicit CStaticDelegate(typename DStaticDelegate::TFunction func) : DStaticDelegate(func) { }
};

template <typename PReturn LEADING_COMMA DELEGATE_PARAMS_TYPENAMES>
class CMultiDelegate<DStaticFunction> : public DMultiDelegate
{
};

#endif /* DELEGATES_PARTIAL_SPECIALIZATION */

#undef DBaseDelegateN
#undef DBaseDelegate
#undef DDelegateN
#undef DDelegate
#undef DStaticDelegateN
#undef DStaticDelegate
#undef DFunction
#undef DStaticFunction
#undef DDelegateData
#undef DStaticDelegateData
#undef DBaseMultiDelegate
#undef DMultiDelegateN
#undef DMultiDelegate

#undef LEADING_COMMA
#undef DELEGATE_PARAMS_TYPENAMES
#undef DELEGATE_PARAMS_TYPES
#undef DELEGATE_PARAMS_VARS
#undef DELEGATE_PARAMS_DEFS
