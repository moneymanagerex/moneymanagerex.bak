/*
 * This is a part of the BugTrap package.
 * Copyright (c) 2005-2007 IntelleSoft.
 * All rights reserved.
 *
 * Description: Delegates pre-processing macros.
 * Author: Maksim Pyatkovskiy.
 *
 * This source code is only intended as a supplement to the
 * BugTrap package reference and related electronic documentation
 * provided with the product. See these sources for detailed
 * information regarding the BugTrap package.
 */

#pragma once

#define _ITEM_N(item, num)                       item##num
#define ITEM_N(item, num)                        _ITEM_N(item, num)

#define REPEAT_ITEM_0(item)
#define REPEAT_ITEM_1(item)                                           item##1
#define REPEAT_ITEM_2(item)                      REPEAT_ITEM_1(item), item##2
#define REPEAT_ITEM_3(item)                      REPEAT_ITEM_2(item), item##3
#define REPEAT_ITEM_4(item)                      REPEAT_ITEM_3(item), item##4
#define REPEAT_ITEM_5(item)                      REPEAT_ITEM_4(item), item##5
#define REPEAT_ITEM_6(item)                      REPEAT_ITEM_5(item), item##6
#define REPEAT_ITEM_7(item)                      REPEAT_ITEM_6(item), item##7
#define REPEAT_ITEM_8(item)                      REPEAT_ITEM_7(item), item##8
#define REPEAT_ITEM_9(item)                      REPEAT_ITEM_8(item), item##9
#define REPEAT_ITEM_10(item)                     REPEAT_ITEM_9(item), item##10

#define _REPEAT_ITEM_N(item, num)                REPEAT_ITEM_##num(item)
#define REPEAT_ITEM_N(item, num)                 _REPEAT_ITEM_N(item, num)

#define REPEAT_TWOITEMS_0(item1, item2)
#define REPEAT_TWOITEMS_1(item1, item2)                                           item1##1 item2##1
#define REPEAT_TWOITEMS_2(item1, item2)          REPEAT_TWOITEMS_1(item1, item2), item1##2 item2##2
#define REPEAT_TWOITEMS_3(item1, item2)          REPEAT_TWOITEMS_2(item1, item2), item1##3 item2##3
#define REPEAT_TWOITEMS_4(item1, item2)          REPEAT_TWOITEMS_3(item1, item2), item1##4 item2##4
#define REPEAT_TWOITEMS_5(item1, item2)          REPEAT_TWOITEMS_4(item1, item2), item1##5 item2##5
#define REPEAT_TWOITEMS_6(item1, item2)          REPEAT_TWOITEMS_5(item1, item2), item1##6 item2##6
#define REPEAT_TWOITEMS_7(item1, item2)          REPEAT_TWOITEMS_6(item1, item2), item1##7 item2##7
#define REPEAT_TWOITEMS_8(item1, item2)          REPEAT_TWOITEMS_7(item1, item2), item1##8 item2##8
#define REPEAT_TWOITEMS_9(item1, item2)          REPEAT_TWOITEMS_8(item1, item2), item1##9 item2##9
#define REPEAT_TWOITEMS_10(item1, item2)         REPEAT_TWOITEMS_9(item1, item2), item1##10 item2##10

#define _REPEAT_TWOITEMS_N(item1, item2, num)    REPEAT_TWOITEMS_##num(item1, item2)
#define REPEAT_TWOITEMS_N(item1, item2, num)     _REPEAT_TWOITEMS_N(item1, item2, num)
