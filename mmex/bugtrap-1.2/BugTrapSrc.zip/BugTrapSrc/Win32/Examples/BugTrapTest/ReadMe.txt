Sample MFC GUI application that generates access violation and uses BugTrap to catch the exception.
Open BugTrapTest.sln solution file in Visual Studio and build the application.
Project executables, PDB files and MAP files are located in "BugTrap for Win32 & .NET\Win32\bin" folder.
You may find a description of project code in "BugTrap Developer's Guide".